export class Article { 
	constructor(public articleId:number, public title:string, public category:string) {
	}
}
    